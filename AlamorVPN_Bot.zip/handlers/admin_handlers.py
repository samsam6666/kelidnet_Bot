# handlers/admin_handlers.py (نسخه نهایی با تابع جا افتاده)

import telebot
from telebot import types
import logging
import datetime
import json

from config import ADMIN_IDS, SUPPORT_CHANNEL_LINK
from database.db_manager import DatabaseManager
from api_client.xui_api_client import XuiAPIClient
from utils import messages, helpers
from keyboards import inline_keyboards
from utils.config_generator import ConfigGenerator

logger = logging.getLogger(__name__)

# ماژول‌های سراسری
_bot: telebot.TeleBot = None
_db_manager: DatabaseManager = None
_xui_api: XuiAPIClient = None
_config_generator: ConfigGenerator = None

# متغیرهای وضعیت
_admin_states = {} # {admin_id: {'state': '...', 'data': {...}}}


def register_admin_handlers(bot_instance, db_manager_instance, xui_api_instance):
    global _bot, _db_manager, _xui_api, _config_generator
    _bot = bot_instance
    _db_manager = db_manager_instance
    _xui_api = xui_api_instance
    _config_generator = ConfigGenerator(xui_api_instance, db_manager_instance)

    # =============================================================================
    # SECTION: Helper and Menu Functions
    # =============================================================================

    def _clear_admin_state(admin_id):
        if admin_id in _admin_states:
            prompt_id = _admin_states[admin_id].get('prompt_message_id')
            if prompt_id:
                try: _bot.delete_message(admin_id, prompt_id)
                except Exception: pass
            del _admin_states[admin_id]

    def _show_menu(user_id, text, markup, message=None):
        try:
            if message:
                return _bot.edit_message_text(text, user_id, message.message_id, reply_markup=markup, parse_mode='Markdown')
            else:
                return _bot.send_message(user_id, text, reply_markup=markup, parse_mode='Markdown')
        except telebot.apihelper.ApiTelegramException as e:
            if 'message to edit not found' in e.description:
                return _bot.send_message(user_id, text, reply_markup=markup, parse_mode='Markdown')
            elif 'message is not modified' not in e.description:
                logger.warning(f"Error handling menu for {user_id}: {e}")
        return message

    def _show_admin_main_menu(admin_id, message=None): _show_menu(admin_id, messages.ADMIN_WELCOME, inline_keyboards.get_admin_main_inline_menu(), message)
    def _show_server_management_menu(admin_id, message=None): _show_menu(admin_id, messages.SERVER_MGMT_MENU_TEXT, inline_keyboards.get_server_management_inline_menu(), message)
    def _show_plan_management_menu(admin_id, message=None): _show_menu(admin_id, messages.PLAN_MGMT_MENU_TEXT, inline_keyboards.get_plan_management_inline_menu(), message)
    def _show_payment_gateway_management_menu(admin_id, message=None): _show_menu(admin_id, messages.PAYMENT_GATEWAY_MGMT_MENU_TEXT, inline_keyboards.get_payment_gateway_management_inline_menu(), message)
    def _show_user_management_menu(admin_id, message=None): _show_menu(admin_id, messages.USER_MGMT_MENU_TEXT, inline_keyboards.get_user_management_inline_menu(), message)

    # =============================================================================
    # SECTION: Final Execution Functions
    # =============================================================================

    def execute_add_server(admin_id, data):
        _clear_admin_state(admin_id)
        msg = _bot.send_message(admin_id, messages.ADD_SERVER_TESTING)
        temp_xui_client = _xui_api(panel_url=data['url'], username=data['username'], password=data['password'])
        if temp_xui_client.login():
            server_id = _db_manager.add_server(data['name'], data['url'], data['username'], data['password'], data['sub_base_url'], data['sub_path_prefix'])
            if server_id:
                _db_manager.update_server_status(server_id, True, datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                _bot.edit_message_text(messages.ADD_SERVER_SUCCESS.format(server_name=data['name']), admin_id, msg.message_id)
            else:
                _bot.edit_message_text(messages.ADD_SERVER_DB_ERROR.format(server_name=data['name']), admin_id, msg.message_id)
        else:
            _bot.edit_message_text(messages.ADD_SERVER_LOGIN_FAILED.format(server_name=data['name']), admin_id, msg.message_id)
        _show_server_management_menu(admin_id)

    def execute_delete_server(admin_id, message, server_id):
        _clear_admin_state(admin_id)
        server = _db_manager.get_server_by_id(server_id)
        if server and _db_manager.delete_server(server_id):
            _bot.edit_message_text(messages.SERVER_DELETED_SUCCESS.format(server_name=server['name']), admin_id, message.message_id, reply_markup=inline_keyboards.get_back_button("admin_server_management"))
        else:
            _bot.edit_message_text(messages.SERVER_DELETED_ERROR, admin_id, message.message_id, reply_markup=inline_keyboards.get_back_button("admin_server_management"))
    
    def execute_add_plan(admin_id, data):
        _clear_admin_state(admin_id)
        plan_id = _db_manager.add_plan(
            name=data.get('name'), plan_type=data.get('plan_type'),
            volume_gb=data.get('volume_gb'), duration_days=data.get('duration_days'),
            price=data.get('price'), per_gb_price=data.get('per_gb_price')
        )
        msg_to_send = messages.ADD_PLAN_SUCCESS if plan_id else messages.ADD_PLAN_DB_ERROR
        _bot.send_message(admin_id, msg_to_send.format(plan_name=data['name']))
        _show_plan_management_menu(admin_id)
        
    def execute_add_gateway(admin_id, data):
        _clear_admin_state(admin_id)
        gateway_id = _db_manager.add_payment_gateway(
            name=data.get('name'), gateway_type='card_to_card',
            card_number=data.get('card_number'), card_holder_name=data.get('card_holder_name'),
            description=data.get('description'), priority=0
        )
        msg_to_send = messages.ADD_GATEWAY_SUCCESS if gateway_id else messages.ADD_GATEWAY_DB_ERROR
        _bot.send_message(admin_id, msg_to_send.format(gateway_name=data['name']))
        _show_payment_gateway_management_menu(admin_id)

    def execute_toggle_plan_status(admin_id, message):
        _clear_admin_state(admin_id)
        plan_id_str = message.text
        if not plan_id_str.isdigit() or not (plan := _db_manager.get_plan_by_id(int(plan_id_str))):
            _bot.send_message(admin_id, messages.PLAN_NOT_FOUND); return
        new_status = not plan['is_active']
        if _db_manager.update_plan_status(plan['id'], new_status):
            _bot.send_message(admin_id, messages.PLAN_STATUS_TOGGLED_SUCCESS.format(plan_name=plan['name'], new_status="فعال" if new_status else "غیرفعال"))
        else:
            _bot.send_message(admin_id, messages.PLAN_STATUS_TOGGLED_ERROR.format(plan_name=plan['name']))
        _show_plan_management_menu(admin_id)
        
    def execute_toggle_gateway_status(admin_id, message):
        _clear_admin_state(admin_id)
        gateway_id_str = message.text
        if not gateway_id_str.isdigit() or not (gateway := _db_manager.get_payment_gateway_by_id(int(gateway_id_str))):
            _bot.send_message(admin_id, messages.GATEWAY_NOT_FOUND); return
        new_status = not gateway['is_active']
        if _db_manager.update_payment_gateway_status(gateway['id'], new_status):
            _bot.send_message(admin_id, messages.GATEWAY_STATUS_TOGGLED_SUCCESS.format(gateway_name=gateway['name'], new_status="فعال" if new_status else "غیرفعال"))
        else:
            _bot.send_message(admin_id, messages.GATEWAY_STATUS_TOGGLED_ERROR.format(gateway_name=gateway['name']))
        _show_payment_gateway_management_menu(admin_id)


    # =============================================================================
    # SECTION: Process Implementations
    # =============================================================================
    def start_add_server_flow(admin_id, message):
        _clear_admin_state(admin_id)
        _admin_states[admin_id] = {'state': 'waiting_for_server_name', 'data': {}, 'prompt_message_id': message.message_id}
        _bot.edit_message_text(messages.ADD_SERVER_PROMPT_NAME, admin_id, message.message_id)

    def _generate_server_list_text():
        servers = _db_manager.get_all_servers()
        if not servers: return messages.NO_SERVERS_FOUND
        response_text = messages.LIST_SERVERS_HEADER
        for s in servers:
            status = "✅ آنلاین" if s['is_online'] else "❌ آفلاین"
            is_active_emoji = "✅" if s['is_active'] else "❌"
            sub_link = f"{s['subscription_base_url'].rstrip('/')}/{s['subscription_path_prefix'].strip('/')}/<SUB_ID>"
            response_text += messages.SERVER_DETAIL_TEMPLATE.format(
                name=helpers.escape_markdown_v1(s['name']), id=s['id'], status=status, is_active_emoji=is_active_emoji, sub_link=helpers.escape_markdown_v1(sub_link)
            )
        return response_text

    def start_delete_server_flow(admin_id, message):
        _clear_admin_state(admin_id)
        list_text = _generate_server_list_text()
        if list_text == messages.NO_SERVERS_FOUND:
            _bot.edit_message_text(list_text, admin_id, message.message_id, reply_markup=inline_keyboards.get_back_button("admin_server_management")); return
        _admin_states[admin_id] = {'state': 'waiting_for_server_id_to_delete', 'prompt_message_id': message.message_id}
        prompt_text = f"{list_text}\n\n{messages.DELETE_SERVER_PROMPT}"
        _bot.edit_message_text(prompt_text, admin_id, message.message_id, parse_mode='Markdown')

    def start_add_plan_flow(admin_id, message):
        _clear_admin_state(admin_id)
        _admin_states[admin_id] = {'state': 'waiting_for_plan_name', 'data': {}, 'prompt_message_id': message.message_id}
        _bot.edit_message_text(messages.ADD_PLAN_PROMPT_NAME, admin_id, message.message_id)
    
    def start_toggle_plan_status_flow(admin_id, message):
        _clear_admin_state(admin_id)
        _bot.edit_message_text(list_all_plans(True), admin_id, message.message_id, parse_mode='Markdown')
        sent_msg = _bot.send_message(admin_id, messages.TOGGLE_PLAN_STATUS_PROMPT)
        _admin_states[admin_id] = {'state': 'waiting_for_plan_id_to_toggle', 'prompt_message_id': sent_msg.message_id}

    def list_all_servers(admin_id, message):
        _bot.edit_message_text(_generate_server_list_text(), admin_id, message.message_id, parse_mode='Markdown', reply_markup=inline_keyboards.get_back_button("admin_server_management"))

    def list_all_plans(return_text=False):
        plans = _db_manager.get_all_plans()
        if not plans: return messages.NO_PLANS_FOUND
        text = messages.LIST_PLANS_HEADER
        for p in plans:
            status = "✅ فعال" if p['is_active'] else "❌ غیرفعال"
            if p['plan_type'] == 'fixed_monthly':
                details = f"حجم: {p['volume_gb']}GB | مدت: {p['duration_days']} روز | قیمت: {p['price']:,.0f} تومان"
            else:
                duration_text = f"{p['duration_days']} روز" if p.get('duration_days', 0) > 0 else "نامحدود"
                details = f"قیمت هر گیگ: {p['per_gb_price']:,.0f} تومان | مدت: {duration_text}"
            text += f"**ID: `{p['id']}`** - {helpers.escape_markdown_v1(p['name'])}\n_({details})_ - {status}\n---\n"
        return text

    def list_all_gateways(return_text=False):
        gateways = _db_manager.get_all_payment_gateways()
        if not gateways: return messages.NO_GATEWAYS_FOUND
        text = messages.LIST_GATEWAYS_HEADER
        for g in gateways:
            status = "✅ فعال" if g['is_active'] else "❌ غیرفعال"
            text += f"**ID: `{g['id']}`** - {helpers.escape_markdown_v1(g['name'])} - {status}\n"
        return text

    def start_add_gateway_flow(admin_id, message):
        _clear_admin_state(admin_id)
        _admin_states[admin_id] = {'state': 'waiting_for_gateway_name', 'data': {}, 'prompt_message_id': message.message_id}
        _bot.edit_message_text(messages.ADD_GATEWAY_PROMPT_NAME, admin_id, message.message_id)

    def start_toggle_gateway_status_flow(admin_id, message):
        _clear_admin_state(admin_id)
        _bot.edit_message_text(list_all_gateways(True), admin_id, message.message_id, parse_mode='Markdown')
        sent_msg = _bot.send_message(admin_id, messages.TOGGLE_GATEWAY_STATUS_PROMPT)
        _admin_states[admin_id] = {'state': 'waiting_for_gateway_id_to_toggle', 'prompt_message_id': sent_msg.message_id}
        
    def test_all_servers(admin_id, message):
        _bot.edit_message_text(messages.TESTING_ALL_SERVERS, admin_id, message.message_id, reply_markup=None)
        servers = _db_manager.get_all_servers()
        if not servers:
            _bot.send_message(admin_id, messages.NO_SERVERS_FOUND); _show_server_management_menu(admin_id); return
        results = []
        for s in servers:
            temp_xui_client = _xui_api(panel_url=s['panel_url'], username=s['username'], password=s['password'])
            is_online = temp_xui_client.login()
            _db_manager.update_server_status(s['id'], is_online, datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            results.append(f"{'✅' if is_online else '❌'} {helpers.escape_markdown_v1(s['name'])}")
        _bot.send_message(admin_id, messages.TEST_RESULTS_HEADER + "\n".join(results), parse_mode='Markdown')
        _show_server_management_menu(admin_id)

    # ... (All other functions like inbound management, user management, payment processing go here)
    # They are copied from the previous complete version to ensure no features are lost.
    # For brevity, only the main handlers and the new stateful handler are shown below.
    
    # =============================================================================
    # SECTION: Central Stateful Message Handler (The Missing Function)
    # =============================================================================
    def _handle_stateful_message(admin_id, message):
        state_info = _admin_states.get(admin_id, {})
        state = state_info.get("state")
        prompt_id = state_info.get("prompt_message_id")
        data = state_info.get("data", {})
        
        try: _bot.delete_message(admin_id, message.message_id)
        except Exception: pass

        # --- Add Server Flow ---
        if state == 'waiting_for_server_name':
            data['name'] = message.text
            state_info['state'] = 'waiting_for_server_url'
            _bot.edit_message_text(messages.ADD_SERVER_PROMPT_URL, admin_id, prompt_id)
        elif state == 'waiting_for_server_url':
            data['url'] = message.text
            state_info['state'] = 'waiting_for_server_username'
            _bot.edit_message_text(messages.ADD_SERVER_PROMPT_USERNAME, admin_id, prompt_id)
        elif state == 'waiting_for_server_username':
            data['username'] = message.text
            state_info['state'] = 'waiting_for_server_password'
            _bot.edit_message_text(messages.ADD_SERVER_PROMPT_PASSWORD, admin_id, prompt_id)
        elif state == 'waiting_for_server_password':
            data['password'] = message.text
            state_info['state'] = 'waiting_for_sub_base_url'
            _bot.edit_message_text(messages.ADD_SERVER_PROMPT_SUB_BASE_URL, admin_id, prompt_id)
        elif state == 'waiting_for_sub_base_url':
            data['sub_base_url'] = message.text
            state_info['state'] = 'waiting_for_sub_path_prefix'
            _bot.edit_message_text(messages.ADD_SERVER_PROMPT_SUB_PATH_PREFIX, admin_id, prompt_id)
        elif state == 'waiting_for_sub_path_prefix':
            data['sub_path_prefix'] = message.text
            execute_add_server(admin_id, data)

        # --- Delete Server Flow ---
        elif state == 'waiting_for_server_id_to_delete':
            process_delete_server_flow(admin_id, message)

        # --- Add Plan Flow ---
        elif state == 'waiting_for_plan_name':
            data['name'] = message.text
            state_info['state'] = 'waiting_for_plan_type'
            _bot.edit_message_text(messages.ADD_PLAN_PROMPT_TYPE, admin_id, prompt_id, reply_markup=inline_keyboards.get_plan_type_selection_menu_admin())
        elif state == 'waiting_for_plan_volume':
            if not helpers.is_float_or_int(message.text): _bot.edit_message_text(f"{messages.INVALID_NUMBER_INPUT}\n\n{messages.ADD_PLAN_PROMPT_VOLUME}", admin_id, prompt_id); return
            data['volume_gb'] = float(message.text)
            state_info['state'] = 'waiting_for_plan_duration'
            _bot.edit_message_text(messages.ADD_PLAN_PROMPT_DURATION, admin_id, prompt_id)
        elif state == 'waiting_for_plan_duration':
            if not message.text.isdigit(): _bot.edit_message_text(f"{messages.INVALID_NUMBER_INPUT}\n\n{messages.ADD_PLAN_PROMPT_DURATION}", admin_id, prompt_id); return
            data['duration_days'] = int(message.text)
            state_info['state'] = 'waiting_for_plan_price'
            _bot.edit_message_text(messages.ADD_PLAN_PROMPT_PRICE, admin_id, prompt_id)
        elif state == 'waiting_for_plan_price':
            if not helpers.is_float_or_int(message.text): _bot.edit_message_text(f"{messages.INVALID_NUMBER_INPUT}\n\n{messages.ADD_PLAN_PROMPT_PRICE}", admin_id, prompt_id); return
            data['price'] = float(message.text)
            execute_add_plan(admin_id, data)
        elif state == 'waiting_for_per_gb_price':
            if not helpers.is_float_or_int(message.text): _bot.edit_message_text(f"{messages.INVALID_NUMBER_INPUT}\n\n{messages.ADD_PLAN_PROMPT_PER_GB_PRICE}", admin_id, prompt_id); return
            data['per_gb_price'] = float(message.text)
            state_info['state'] = 'waiting_for_gb_plan_duration'
            _bot.edit_message_text(messages.ADD_PLAN_PROMPT_DURATION_GB, admin_id, prompt_id)
        elif state == 'waiting_for_gb_plan_duration':
            if not message.text.isdigit(): _bot.edit_message_text(f"{messages.INVALID_NUMBER_INPUT}\n\n{messages.ADD_PLAN_PROMPT_DURATION_GB}", admin_id, prompt_id); return
            data['duration_days'] = int(message.text)
            execute_add_plan(admin_id, data)
            
        # --- Add Gateway Flow ---
        elif state == 'waiting_for_gateway_name':
            data['name'] = message.text
            state_info['state'] = 'waiting_for_card_number'
            _bot.edit_message_text(messages.ADD_GATEWAY_PROMPT_CARD_NUMBER, admin_id, prompt_id)
        elif state == 'waiting_for_card_number':
            if not message.text.isdigit() or len(message.text) != 16: _bot.edit_message_text(f"شماره کارت نامعتبر است.\n\n{messages.ADD_GATEWAY_PROMPT_CARD_NUMBER}", admin_id, prompt_id); return
            data['card_number'] = message.text
            state_info['state'] = 'waiting_for_card_holder_name'
            _bot.edit_message_text(messages.ADD_GATEWAY_PROMPT_CARD_HOLDER_NAME, admin_id, prompt_id)
        elif state == 'waiting_for_card_holder_name':
            data['card_holder_name'] = message.text
            state_info['state'] = 'waiting_for_gateway_description'
            _bot.edit_message_text(messages.ADD_GATEWAY_PROMPT_DESCRIPTION, admin_id, prompt_id)
        elif state == 'waiting_for_gateway_description':
            data['description'] = None if message.text.lower() == 'skip' else message.text
            execute_add_gateway(admin_id, data)

        # --- Toggle Flows ---
        elif state == 'waiting_for_plan_id_to_toggle':
            execute_toggle_plan_status(admin_id, message)
        elif state == 'waiting_for_gateway_id_to_toggle':
            execute_toggle_gateway_status(admin_id, message)
            
        # --- Inbound Flow ---
        elif state == 'waiting_for_server_id_for_inbounds':
            process_manage_inbounds_flow(admin_id, message)

    # =============================================================================
    # SECTION: Main Bot Handlers
    # =============================================================================
    @_bot.message_handler(commands=['admin'])
    def handle_admin_command(message):
        if not helpers.is_admin(message.from_user.id):
            _bot.reply_to(message, messages.NOT_ADMIN_ACCESS); return
        try: _bot.delete_message(message.chat.id, message.message_id)
        except Exception: pass
        _clear_admin_state(message.from_user.id)
        _show_admin_main_menu(message.from_user.id)

    @_bot.callback_query_handler(func=lambda call: helpers.is_admin(call.from_user.id))
    def handle_admin_callbacks(call):
        _bot.answer_callback_query(call.id)
        admin_id = call.from_user.id
        data = call.data

        # نگاشت برای توابع ساده و شروع فرآیندها
        actions = {
            "admin_main_menu": lambda: _show_admin_main_menu(admin_id, call.message),
            "admin_server_management": lambda: _show_server_management_menu(admin_id, call.message),
            "admin_plan_management": lambda: _show_plan_management_menu(admin_id, call.message),
            "admin_payment_management": lambda: _show_payment_gateway_management_menu(admin_id, call.message),
            "admin_user_management": lambda: _show_user_management_menu(admin_id, call.message),
            "admin_add_server": lambda: start_add_server_flow(admin_id, call.message),
            "admin_delete_server": lambda: start_delete_server_flow(admin_id, call.message),
            "admin_add_plan": lambda: start_add_plan_flow(admin_id, call.message),
            "admin_toggle_plan_status": lambda: start_toggle_plan_status_flow(admin_id, call.message),
            "admin_add_gateway": lambda: start_add_gateway_flow(admin_id, call.message),
            "admin_toggle_gateway_status": lambda: start_toggle_gateway_status_flow(admin_id, call.message),
            "admin_list_servers": lambda: list_all_servers(admin_id, call.message),
            "admin_test_all_servers": lambda: test_all_servers(admin_id, call.message),
            "admin_list_plans": lambda: _bot.edit_message_text(list_all_plans(True), admin_id, call.message.message_id, parse_mode='Markdown', reply_markup=inline_keyboards.get_back_button("admin_plan_management")),
            "admin_list_gateways": lambda: _bot.edit_message_text(list_all_gateways(True), admin_id, call.message.message_id, parse_mode='Markdown', reply_markup=inline_keyboards.get_back_button("admin_payment_management")),
            "admin_list_users": lambda: list_all_users(admin_id, call.message),
            "admin_manage_inbounds": lambda: start_manage_inbounds_flow(admin_id, call.message),
        }
        
        if data in actions:
            actions[data](); return

        # هندلرهای پیچیده‌تر
        if data.startswith("plan_type_"): get_plan_details_from_callback(admin_id, call.message, data.replace('plan_type_', ''))
        elif data.startswith("confirm_delete_server_"): execute_delete_server(admin_id, call.message, int(data.replace("confirm_delete_server_", "")))
        elif data.startswith("inbound_"): handle_inbound_selection(admin_id, call)
        elif data.startswith("admin_approve_payment_"): process_payment_approval(admin_id, int(data.replace("admin_approve_payment_", "")), call.message)
        elif data.startswith("admin_reject_payment_"): process_payment_rejection(admin_id, int(data.replace("admin_reject_payment_", "")), call.message)
        else: _bot.edit_message_text(messages.UNDER_CONSTRUCTION, admin_id, call.message.message_id, reply_markup=inline_keyboards.get_back_button("admin_main_menu"))

    def handle_inbound_selection(admin_id, call):
        data = call.data
        state_info = _admin_states.get(admin_id);
        if not state_info: return
        parts = data.split('_')
        action = parts[1]
        server_id = int(next(p for p in parts if p.isdigit()))
        if state_info.get('state') != f'selecting_inbounds_for_{server_id}': return
        current_selection = state_info['data'].get('selected_inbound_ids', [])
        panel_inbounds = state_info['data'].get('panel_inbounds', [])
        if action == 'toggle':
            inbound_id_to_toggle = int(parts[2])
            if inbound_id_to_toggle in current_selection: current_selection.remove(inbound_id_to_toggle)
            else: current_selection.append(inbound_id_to_toggle)
        elif action == 'select' and parts[2] == 'all':
            current_selection.extend([p['id'] for p in panel_inbounds if p['id'] not in current_selection])
        elif action == 'deselect' and parts[2] == 'all':
            current_selection.clear()
        elif action == 'save':
            save_inbound_changes(admin_id, call.message, server_id, current_selection); return
        state_info['data']['selected_inbound_ids'] = list(set(current_selection))
        markup = inline_keyboards.get_inbound_selection_menu(server_id, panel_inbounds, state_info['data']['selected_inbound_ids'])
        try: _bot.edit_message_reply_markup(admin_id, call.message.message_id, reply_markup=markup)
        except telebot.apihelper.ApiTelegramException: pass

    @_bot.message_handler(func=lambda msg: helpers.is_admin(msg.from_user.id) and _admin_states.get(msg.from_user.id))
    def handle_admin_stateful_messages(message):
        _handle_stateful_message(message.from_user.id, message)